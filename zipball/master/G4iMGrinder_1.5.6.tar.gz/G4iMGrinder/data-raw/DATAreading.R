library(devtools)
load(paste0(getwd(), "/data-raw/KTFS.DDBB.RData", collapse = ""))
use_data(Known_to_form_Quadruplex)

